--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6
-- Dumped by pg_dump version 14.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dbname;
--
-- Name: dbname; Type: DATABASE; Schema: -; Owner: dbuser
--

CREATE DATABASE dbname WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE dbname OWNER TO dbuser;

\connect dbname

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO dbuser;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO dbuser;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO dbuser;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO dbuser;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO dbuser;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO dbuser;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO dbuser;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO dbuser;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO dbuser;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO dbuser;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO dbuser;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO dbuser;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO dbuser;

--
-- Name: service_acceptor; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_acceptor (
    id bigint NOT NULL,
    first_name character varying(50) NOT NULL,
    second_name character varying(50) NOT NULL,
    patronim character varying(50) NOT NULL
);


ALTER TABLE public.service_acceptor OWNER TO dbuser;

--
-- Name: service_acceptor_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_acceptor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_acceptor_id_seq OWNER TO dbuser;

--
-- Name: service_acceptor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_acceptor_id_seq OWNED BY public.service_acceptor.id;


--
-- Name: service_avto; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_avto (
    id bigint NOT NULL,
    vin character varying(17) NOT NULL,
    number character varying(9) NOT NULL,
    sts character varying(10) NOT NULL,
    sold_date date NOT NULL,
    mileage integer NOT NULL,
    car_model_id bigint NOT NULL,
    owner_id bigint NOT NULL
);


ALTER TABLE public.service_avto OWNER TO dbuser;

--
-- Name: service_avto_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_avto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_avto_id_seq OWNER TO dbuser;

--
-- Name: service_avto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_avto_id_seq OWNED BY public.service_avto.id;


--
-- Name: service_carmodel; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_carmodel (
    id bigint NOT NULL,
    model character varying(50) NOT NULL,
    image character varying(100) NOT NULL,
    engine_id bigint NOT NULL
);


ALTER TABLE public.service_carmodel OWNER TO dbuser;

--
-- Name: service_carmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_carmodel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_carmodel_id_seq OWNER TO dbuser;

--
-- Name: service_carmodel_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_carmodel_id_seq OWNED BY public.service_carmodel.id;


--
-- Name: service_engine; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_engine (
    id bigint NOT NULL,
    model character varying(50) NOT NULL,
    oil_count numeric(3,1) NOT NULL,
    engine_vol numeric(3,1) NOT NULL,
    oil_id bigint NOT NULL
);


ALTER TABLE public.service_engine OWNER TO dbuser;

--
-- Name: service_engine_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_engine_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_engine_id_seq OWNER TO dbuser;

--
-- Name: service_engine_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_engine_id_seq OWNED BY public.service_engine.id;


--
-- Name: service_maintenance; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_maintenance (
    id bigint NOT NULL,
    operation character varying(150) NOT NULL,
    working_time numeric(3,1) NOT NULL,
    car_model_id bigint NOT NULL,
    working_type_id bigint NOT NULL
);


ALTER TABLE public.service_maintenance OWNER TO dbuser;

--
-- Name: service_maintenance_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_maintenance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_maintenance_id_seq OWNER TO dbuser;

--
-- Name: service_maintenance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_maintenance_id_seq OWNED BY public.service_maintenance.id;


--
-- Name: service_maintenance_parts; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_maintenance_parts (
    id bigint NOT NULL,
    maintenance_id bigint NOT NULL,
    part_id bigint NOT NULL
);


ALTER TABLE public.service_maintenance_parts OWNER TO dbuser;

--
-- Name: service_maintenance_parts_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_maintenance_parts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_maintenance_parts_id_seq OWNER TO dbuser;

--
-- Name: service_maintenance_parts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_maintenance_parts_id_seq OWNED BY public.service_maintenance_parts.id;


--
-- Name: service_oil; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_oil (
    id bigint NOT NULL,
    title character varying(50) NOT NULL,
    viscosity character varying(7) NOT NULL,
    price numeric(9,2) NOT NULL
);


ALTER TABLE public.service_oil OWNER TO dbuser;

--
-- Name: service_oil_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_oil_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_oil_id_seq OWNER TO dbuser;

--
-- Name: service_oil_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_oil_id_seq OWNED BY public.service_oil.id;


--
-- Name: service_part; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_part (
    id bigint NOT NULL,
    spare_part character varying(150) NOT NULL,
    price numeric(9,2) NOT NULL
);


ALTER TABLE public.service_part OWNER TO dbuser;

--
-- Name: service_part_compatible_car; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_part_compatible_car (
    id bigint NOT NULL,
    part_id bigint NOT NULL,
    carmodel_id bigint NOT NULL
);


ALTER TABLE public.service_part_compatible_car OWNER TO dbuser;

--
-- Name: service_part_compatible_car_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_part_compatible_car_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_part_compatible_car_id_seq OWNER TO dbuser;

--
-- Name: service_part_compatible_car_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_part_compatible_car_id_seq OWNED BY public.service_part_compatible_car.id;


--
-- Name: service_part_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_part_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_part_id_seq OWNER TO dbuser;

--
-- Name: service_part_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_part_id_seq OWNED BY public.service_part.id;


--
-- Name: service_registration; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_registration (
    id bigint NOT NULL,
    day date NOT NULL,
    "time" time without time zone NOT NULL,
    acceptor_id bigint NOT NULL,
    avto_id bigint NOT NULL,
    maintenance_id bigint NOT NULL,
    canceled boolean NOT NULL
);


ALTER TABLE public.service_registration OWNER TO dbuser;

--
-- Name: service_registration_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_registration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_registration_id_seq OWNER TO dbuser;

--
-- Name: service_registration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_registration_id_seq OWNED BY public.service_registration.id;


--
-- Name: service_workingtype; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.service_workingtype (
    id bigint NOT NULL,
    working_type character varying(50) NOT NULL,
    price numeric(4,0) NOT NULL
);


ALTER TABLE public.service_workingtype OWNER TO dbuser;

--
-- Name: service_workingprice_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.service_workingprice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_workingprice_id_seq OWNER TO dbuser;

--
-- Name: service_workingprice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.service_workingprice_id_seq OWNED BY public.service_workingtype.id;


--
-- Name: users_customuser; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.users_customuser (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    first_name character varying(50) NOT NULL,
    last_name character varying(50) NOT NULL,
    patronim character varying(50) NOT NULL,
    role character varying(7) NOT NULL,
    email character varying(254) NOT NULL
);


ALTER TABLE public.users_customuser OWNER TO dbuser;

--
-- Name: users_customuser_groups; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.users_customuser_groups (
    id bigint NOT NULL,
    customuser_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_customuser_groups OWNER TO dbuser;

--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.users_customuser_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_customuser_groups_id_seq OWNER TO dbuser;

--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.users_customuser_groups_id_seq OWNED BY public.users_customuser_groups.id;


--
-- Name: users_customuser_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.users_customuser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_customuser_id_seq OWNER TO dbuser;

--
-- Name: users_customuser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.users_customuser_id_seq OWNED BY public.users_customuser.id;


--
-- Name: users_customuser_user_permissions; Type: TABLE; Schema: public; Owner: dbuser
--

CREATE TABLE public.users_customuser_user_permissions (
    id bigint NOT NULL,
    customuser_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_customuser_user_permissions OWNER TO dbuser;

--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: dbuser
--

CREATE SEQUENCE public.users_customuser_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_customuser_user_permissions_id_seq OWNER TO dbuser;

--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: dbuser
--

ALTER SEQUENCE public.users_customuser_user_permissions_id_seq OWNED BY public.users_customuser_user_permissions.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: service_acceptor id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_acceptor ALTER COLUMN id SET DEFAULT nextval('public.service_acceptor_id_seq'::regclass);


--
-- Name: service_avto id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_avto ALTER COLUMN id SET DEFAULT nextval('public.service_avto_id_seq'::regclass);


--
-- Name: service_carmodel id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_carmodel ALTER COLUMN id SET DEFAULT nextval('public.service_carmodel_id_seq'::regclass);


--
-- Name: service_engine id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_engine ALTER COLUMN id SET DEFAULT nextval('public.service_engine_id_seq'::regclass);


--
-- Name: service_maintenance id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance ALTER COLUMN id SET DEFAULT nextval('public.service_maintenance_id_seq'::regclass);


--
-- Name: service_maintenance_parts id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance_parts ALTER COLUMN id SET DEFAULT nextval('public.service_maintenance_parts_id_seq'::regclass);


--
-- Name: service_oil id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_oil ALTER COLUMN id SET DEFAULT nextval('public.service_oil_id_seq'::regclass);


--
-- Name: service_part id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_part ALTER COLUMN id SET DEFAULT nextval('public.service_part_id_seq'::regclass);


--
-- Name: service_part_compatible_car id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_part_compatible_car ALTER COLUMN id SET DEFAULT nextval('public.service_part_compatible_car_id_seq'::regclass);


--
-- Name: service_registration id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_registration ALTER COLUMN id SET DEFAULT nextval('public.service_registration_id_seq'::regclass);


--
-- Name: service_workingtype id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_workingtype ALTER COLUMN id SET DEFAULT nextval('public.service_workingprice_id_seq'::regclass);


--
-- Name: users_customuser id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_id_seq'::regclass);


--
-- Name: users_customuser_groups id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_groups ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_groups_id_seq'::regclass);


--
-- Name: users_customuser_user_permissions id; Type: DEFAULT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_customuser_user_permissions_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3590.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3592.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3588.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3600.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3586.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3584.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3623.dat';

--
-- Data for Name: service_acceptor; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_acceptor (id, first_name, second_name, patronim) FROM stdin;
\.
COPY public.service_acceptor (id, first_name, second_name, patronim) FROM '$$PATH$$/3602.dat';

--
-- Data for Name: service_avto; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_avto (id, vin, number, sts, sold_date, mileage, car_model_id, owner_id) FROM stdin;
\.
COPY public.service_avto (id, vin, number, sts, sold_date, mileage, car_model_id, owner_id) FROM '$$PATH$$/3604.dat';

--
-- Data for Name: service_carmodel; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_carmodel (id, model, image, engine_id) FROM stdin;
\.
COPY public.service_carmodel (id, model, image, engine_id) FROM '$$PATH$$/3606.dat';

--
-- Data for Name: service_engine; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_engine (id, model, oil_count, engine_vol, oil_id) FROM stdin;
\.
COPY public.service_engine (id, model, oil_count, engine_vol, oil_id) FROM '$$PATH$$/3608.dat';

--
-- Data for Name: service_maintenance; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_maintenance (id, operation, working_time, car_model_id, working_type_id) FROM stdin;
\.
COPY public.service_maintenance (id, operation, working_time, car_model_id, working_type_id) FROM '$$PATH$$/3610.dat';

--
-- Data for Name: service_maintenance_parts; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_maintenance_parts (id, maintenance_id, part_id) FROM stdin;
\.
COPY public.service_maintenance_parts (id, maintenance_id, part_id) FROM '$$PATH$$/3622.dat';

--
-- Data for Name: service_oil; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_oil (id, title, viscosity, price) FROM stdin;
\.
COPY public.service_oil (id, title, viscosity, price) FROM '$$PATH$$/3612.dat';

--
-- Data for Name: service_part; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_part (id, spare_part, price) FROM stdin;
\.
COPY public.service_part (id, spare_part, price) FROM '$$PATH$$/3618.dat';

--
-- Data for Name: service_part_compatible_car; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_part_compatible_car (id, part_id, carmodel_id) FROM stdin;
\.
COPY public.service_part_compatible_car (id, part_id, carmodel_id) FROM '$$PATH$$/3620.dat';

--
-- Data for Name: service_registration; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_registration (id, day, "time", acceptor_id, avto_id, maintenance_id, canceled) FROM stdin;
\.
COPY public.service_registration (id, day, "time", acceptor_id, avto_id, maintenance_id, canceled) FROM '$$PATH$$/3616.dat';

--
-- Data for Name: service_workingtype; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.service_workingtype (id, working_type, price) FROM stdin;
\.
COPY public.service_workingtype (id, working_type, price) FROM '$$PATH$$/3614.dat';

--
-- Data for Name: users_customuser; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.users_customuser (id, password, last_login, is_superuser, username, is_staff, is_active, date_joined, first_name, last_name, patronim, role, email) FROM stdin;
\.
COPY public.users_customuser (id, password, last_login, is_superuser, username, is_staff, is_active, date_joined, first_name, last_name, patronim, role, email) FROM '$$PATH$$/3594.dat';

--
-- Data for Name: users_customuser_groups; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.users_customuser_groups (id, customuser_id, group_id) FROM stdin;
\.
COPY public.users_customuser_groups (id, customuser_id, group_id) FROM '$$PATH$$/3596.dat';

--
-- Data for Name: users_customuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: dbuser
--

COPY public.users_customuser_user_permissions (id, customuser_id, permission_id) FROM stdin;
\.
COPY public.users_customuser_user_permissions (id, customuser_id, permission_id) FROM '$$PATH$$/3598.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 68, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 33, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 16, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 30, true);


--
-- Name: service_acceptor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_acceptor_id_seq', 1, false);


--
-- Name: service_avto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_avto_id_seq', 7, true);


--
-- Name: service_carmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_carmodel_id_seq', 1, true);


--
-- Name: service_engine_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_engine_id_seq', 2, true);


--
-- Name: service_maintenance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_maintenance_id_seq', 1, false);


--
-- Name: service_maintenance_parts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_maintenance_parts_id_seq', 1, false);


--
-- Name: service_oil_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_oil_id_seq', 2, true);


--
-- Name: service_part_compatible_car_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_part_compatible_car_id_seq', 1, false);


--
-- Name: service_part_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_part_id_seq', 1, false);


--
-- Name: service_registration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_registration_id_seq', 1, false);


--
-- Name: service_workingprice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.service_workingprice_id_seq', 1, false);


--
-- Name: users_customuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.users_customuser_groups_id_seq', 1, false);


--
-- Name: users_customuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.users_customuser_id_seq', 14, true);


--
-- Name: users_customuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: dbuser
--

SELECT pg_catalog.setval('public.users_customuser_user_permissions_id_seq', 1, false);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: service_oil oil_uq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_oil
    ADD CONSTRAINT oil_uq UNIQUE (title, viscosity);


--
-- Name: service_acceptor service_acceptor_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_acceptor
    ADD CONSTRAINT service_acceptor_pkey PRIMARY KEY (id);


--
-- Name: service_avto service_avto_number_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_avto
    ADD CONSTRAINT service_avto_number_key UNIQUE (number);


--
-- Name: service_avto service_avto_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_avto
    ADD CONSTRAINT service_avto_pkey PRIMARY KEY (id);


--
-- Name: service_avto service_avto_sts_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_avto
    ADD CONSTRAINT service_avto_sts_key UNIQUE (sts);


--
-- Name: service_avto service_avto_vin_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_avto
    ADD CONSTRAINT service_avto_vin_key UNIQUE (vin);


--
-- Name: service_carmodel service_carmodel_model_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_carmodel
    ADD CONSTRAINT service_carmodel_model_key UNIQUE (model);


--
-- Name: service_carmodel service_carmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_carmodel
    ADD CONSTRAINT service_carmodel_pkey PRIMARY KEY (id);


--
-- Name: service_engine service_engine_model_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_engine
    ADD CONSTRAINT service_engine_model_key UNIQUE (model);


--
-- Name: service_engine service_engine_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_engine
    ADD CONSTRAINT service_engine_pkey PRIMARY KEY (id);


--
-- Name: service_maintenance service_maintenance_operation_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance
    ADD CONSTRAINT service_maintenance_operation_key UNIQUE (operation);


--
-- Name: service_maintenance_parts service_maintenance_parts_maintenance_id_part_id_52097422_uniq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance_parts
    ADD CONSTRAINT service_maintenance_parts_maintenance_id_part_id_52097422_uniq UNIQUE (maintenance_id, part_id);


--
-- Name: service_maintenance_parts service_maintenance_parts_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance_parts
    ADD CONSTRAINT service_maintenance_parts_pkey PRIMARY KEY (id);


--
-- Name: service_maintenance service_maintenance_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance
    ADD CONSTRAINT service_maintenance_pkey PRIMARY KEY (id);


--
-- Name: service_oil service_oil_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_oil
    ADD CONSTRAINT service_oil_pkey PRIMARY KEY (id);


--
-- Name: service_part_compatible_car service_part_compatible_car_part_id_carmodel_id_a0a7ffc5_uniq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_part_compatible_car
    ADD CONSTRAINT service_part_compatible_car_part_id_carmodel_id_a0a7ffc5_uniq UNIQUE (part_id, carmodel_id);


--
-- Name: service_part_compatible_car service_part_compatible_car_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_part_compatible_car
    ADD CONSTRAINT service_part_compatible_car_pkey PRIMARY KEY (id);


--
-- Name: service_part service_part_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_part
    ADD CONSTRAINT service_part_pkey PRIMARY KEY (id);


--
-- Name: service_part service_part_spare_part_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_part
    ADD CONSTRAINT service_part_spare_part_key UNIQUE (spare_part);


--
-- Name: service_registration service_registration_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_registration
    ADD CONSTRAINT service_registration_pkey PRIMARY KEY (id);


--
-- Name: service_workingtype service_workingprice_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_workingtype
    ADD CONSTRAINT service_workingprice_pkey PRIMARY KEY (id);


--
-- Name: service_workingtype service_workingprice_working_type_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_workingtype
    ADD CONSTRAINT service_workingprice_working_type_key UNIQUE (working_type);


--
-- Name: users_customuser users_customuser_email_6445acef_uniq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser
    ADD CONSTRAINT users_customuser_email_6445acef_uniq UNIQUE (email);


--
-- Name: users_customuser_groups users_customuser_groups_customuser_id_group_id_76b619e3_uniq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_groups_customuser_id_group_id_76b619e3_uniq UNIQUE (customuser_id, group_id);


--
-- Name: users_customuser_groups users_customuser_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_groups_pkey PRIMARY KEY (id);


--
-- Name: users_customuser users_customuser_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser
    ADD CONSTRAINT users_customuser_pkey PRIMARY KEY (id);


--
-- Name: users_customuser_user_permissions users_customuser_user_pe_customuser_id_permission_7a7debf6_uniq; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_user_pe_customuser_id_permission_7a7debf6_uniq UNIQUE (customuser_id, permission_id);


--
-- Name: users_customuser_user_permissions users_customuser_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_customuser users_customuser_username_key; Type: CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser
    ADD CONSTRAINT users_customuser_username_key UNIQUE (username);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: service_avto_car_model_id_a3fbef3b; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_avto_car_model_id_a3fbef3b ON public.service_avto USING btree (car_model_id);


--
-- Name: service_avto_number_6ae9c329_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_avto_number_6ae9c329_like ON public.service_avto USING btree (number varchar_pattern_ops);


--
-- Name: service_avto_owner_id_e95bef6a; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_avto_owner_id_e95bef6a ON public.service_avto USING btree (owner_id);


--
-- Name: service_avto_sts_b9895193_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_avto_sts_b9895193_like ON public.service_avto USING btree (sts varchar_pattern_ops);


--
-- Name: service_avto_vin_5aeaeaa6_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_avto_vin_5aeaeaa6_like ON public.service_avto USING btree (vin varchar_pattern_ops);


--
-- Name: service_carmodel_engine_id_3ffedd24; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_carmodel_engine_id_3ffedd24 ON public.service_carmodel USING btree (engine_id);


--
-- Name: service_carmodel_model_2e662ead_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_carmodel_model_2e662ead_like ON public.service_carmodel USING btree (model varchar_pattern_ops);


--
-- Name: service_engine_model_4e989f57_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_engine_model_4e989f57_like ON public.service_engine USING btree (model varchar_pattern_ops);


--
-- Name: service_engine_oil_id_b1e38c6a; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_engine_oil_id_b1e38c6a ON public.service_engine USING btree (oil_id);


--
-- Name: service_maintenance_car_model_id_a86b1a7c; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_maintenance_car_model_id_a86b1a7c ON public.service_maintenance USING btree (car_model_id);


--
-- Name: service_maintenance_operation_002d2e13_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_maintenance_operation_002d2e13_like ON public.service_maintenance USING btree (operation varchar_pattern_ops);


--
-- Name: service_maintenance_parts_maintenance_id_6a562318; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_maintenance_parts_maintenance_id_6a562318 ON public.service_maintenance_parts USING btree (maintenance_id);


--
-- Name: service_maintenance_parts_part_id_5f5ae0f0; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_maintenance_parts_part_id_5f5ae0f0 ON public.service_maintenance_parts USING btree (part_id);


--
-- Name: service_maintenance_working_type_id_70f2388c; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_maintenance_working_type_id_70f2388c ON public.service_maintenance USING btree (working_type_id);


--
-- Name: service_part_compatible_car_carmodel_id_1cb7eeae; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_part_compatible_car_carmodel_id_1cb7eeae ON public.service_part_compatible_car USING btree (carmodel_id);


--
-- Name: service_part_compatible_car_part_id_1f4e737f; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_part_compatible_car_part_id_1f4e737f ON public.service_part_compatible_car USING btree (part_id);


--
-- Name: service_part_spare_part_8594550b_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_part_spare_part_8594550b_like ON public.service_part USING btree (spare_part varchar_pattern_ops);


--
-- Name: service_registration_acceptor_id_216ec6b1; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_registration_acceptor_id_216ec6b1 ON public.service_registration USING btree (acceptor_id);


--
-- Name: service_registration_avto_id_fe582e90; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_registration_avto_id_fe582e90 ON public.service_registration USING btree (avto_id);


--
-- Name: service_registration_maintenance_id_690c1361; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_registration_maintenance_id_690c1361 ON public.service_registration USING btree (maintenance_id);


--
-- Name: service_workingprice_working_type_fbdeff56_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX service_workingprice_working_type_fbdeff56_like ON public.service_workingtype USING btree (working_type varchar_pattern_ops);


--
-- Name: users_customuser_email_6445acef_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX users_customuser_email_6445acef_like ON public.users_customuser USING btree (email varchar_pattern_ops);


--
-- Name: users_customuser_groups_customuser_id_958147bf; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX users_customuser_groups_customuser_id_958147bf ON public.users_customuser_groups USING btree (customuser_id);


--
-- Name: users_customuser_groups_group_id_01390b14; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX users_customuser_groups_group_id_01390b14 ON public.users_customuser_groups USING btree (group_id);


--
-- Name: users_customuser_user_permissions_customuser_id_5771478b; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX users_customuser_user_permissions_customuser_id_5771478b ON public.users_customuser_user_permissions USING btree (customuser_id);


--
-- Name: users_customuser_user_permissions_permission_id_baaa2f74; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX users_customuser_user_permissions_permission_id_baaa2f74 ON public.users_customuser_user_permissions USING btree (permission_id);


--
-- Name: users_customuser_username_80452fdf_like; Type: INDEX; Schema: public; Owner: dbuser
--

CREATE INDEX users_customuser_username_80452fdf_like ON public.users_customuser USING btree (username varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_customuser_id FOREIGN KEY (user_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_avto service_avto_car_model_id_a3fbef3b_fk_service_carmodel_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_avto
    ADD CONSTRAINT service_avto_car_model_id_a3fbef3b_fk_service_carmodel_id FOREIGN KEY (car_model_id) REFERENCES public.service_carmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_avto service_avto_owner_id_e95bef6a_fk_users_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_avto
    ADD CONSTRAINT service_avto_owner_id_e95bef6a_fk_users_customuser_id FOREIGN KEY (owner_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_carmodel service_carmodel_engine_id_3ffedd24_fk_service_engine_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_carmodel
    ADD CONSTRAINT service_carmodel_engine_id_3ffedd24_fk_service_engine_id FOREIGN KEY (engine_id) REFERENCES public.service_engine(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_engine service_engine_oil_id_b1e38c6a_fk_service_oil_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_engine
    ADD CONSTRAINT service_engine_oil_id_b1e38c6a_fk_service_oil_id FOREIGN KEY (oil_id) REFERENCES public.service_oil(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_maintenance_parts service_maintenance__maintenance_id_6a562318_fk_service_m; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance_parts
    ADD CONSTRAINT service_maintenance__maintenance_id_6a562318_fk_service_m FOREIGN KEY (maintenance_id) REFERENCES public.service_maintenance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_maintenance service_maintenance_car_model_id_a86b1a7c_fk_service_c; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance
    ADD CONSTRAINT service_maintenance_car_model_id_a86b1a7c_fk_service_c FOREIGN KEY (car_model_id) REFERENCES public.service_carmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_maintenance_parts service_maintenance_parts_part_id_5f5ae0f0_fk_service_part_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance_parts
    ADD CONSTRAINT service_maintenance_parts_part_id_5f5ae0f0_fk_service_part_id FOREIGN KEY (part_id) REFERENCES public.service_part(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_maintenance service_maintenance_working_type_id_70f2388c_fk_service_w; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_maintenance
    ADD CONSTRAINT service_maintenance_working_type_id_70f2388c_fk_service_w FOREIGN KEY (working_type_id) REFERENCES public.service_workingtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_part_compatible_car service_part_compati_carmodel_id_1cb7eeae_fk_service_c; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_part_compatible_car
    ADD CONSTRAINT service_part_compati_carmodel_id_1cb7eeae_fk_service_c FOREIGN KEY (carmodel_id) REFERENCES public.service_carmodel(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_part_compatible_car service_part_compatible_car_part_id_1f4e737f_fk_service_part_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_part_compatible_car
    ADD CONSTRAINT service_part_compatible_car_part_id_1f4e737f_fk_service_part_id FOREIGN KEY (part_id) REFERENCES public.service_part(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_registration service_registration_acceptor_id_216ec6b1_fk_service_a; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_registration
    ADD CONSTRAINT service_registration_acceptor_id_216ec6b1_fk_service_a FOREIGN KEY (acceptor_id) REFERENCES public.service_acceptor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_registration service_registration_avto_id_fe582e90_fk_service_avto_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_registration
    ADD CONSTRAINT service_registration_avto_id_fe582e90_fk_service_avto_id FOREIGN KEY (avto_id) REFERENCES public.service_avto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: service_registration service_registration_maintenance_id_690c1361_fk_service_m; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.service_registration
    ADD CONSTRAINT service_registration_maintenance_id_690c1361_fk_service_m FOREIGN KEY (maintenance_id) REFERENCES public.service_maintenance(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_groups users_customuser_gro_customuser_id_958147bf_fk_users_cus; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_gro_customuser_id_958147bf_fk_users_cus FOREIGN KEY (customuser_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_groups users_customuser_groups_group_id_01390b14_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_groups
    ADD CONSTRAINT users_customuser_groups_group_id_01390b14_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_user_permissions users_customuser_use_customuser_id_5771478b_fk_users_cus; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_use_customuser_id_5771478b_fk_users_cus FOREIGN KEY (customuser_id) REFERENCES public.users_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_customuser_user_permissions users_customuser_use_permission_id_baaa2f74_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: dbuser
--

ALTER TABLE ONLY public.users_customuser_user_permissions
    ADD CONSTRAINT users_customuser_use_permission_id_baaa2f74_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

